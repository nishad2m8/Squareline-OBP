# Display panel (CYD) with lvgl 

## Get started

1. rename ```libraries``` folder to  ```lib```
2. rename ```ui.ino``` file locatted in side ui folder  to ```main.cpp``` 
3. rename ```ui``` folder to ```scr```
4. open in in vs code using platformio compile and upload

## Read more at
1. https://github.com/rzeldent/esp32-smartdisplay
2. https://github.com/rzeldent/esp32-smartdisplay-demo