#ifndef _2432S028R_H_
#define _2432S028R_H_

#include <lvgl.h>                    // LittlevGL library for GUI
#include <TFT_eSPI.h>                // TFT_eSPI library for TFT display
#include <XPT2046_Touchscreen.h>     // XPT2046 touchscreen library

// Touchscreen pin definitions
#define XPT2046_IRQ   36   // Interrupt Pin
#define XPT2046_MOSI  32   // SPI MOSI Pin (Data In)
#define XPT2046_MISO  39   // SPI MISO Pin (Data Out)
#define XPT2046_CLK   25   // SPI Clock Pin
#define XPT2046_CS    33   // SPI Chip Select Pin

// Screen resolution
#define SCREEN_WIDTH  240
#define SCREEN_HEIGHT 320

// SPI and touchscreen objects
SPIClass touchscreenSPI = SPIClass(VSPI);    // SPI bus for touchscreen
XPT2046_Touchscreen touchscreen(XPT2046_CS, XPT2046_IRQ); // Create touchscreen object

// Buffer for LVGL display
#define DRAW_BUF_SIZE (SCREEN_WIDTH * SCREEN_HEIGHT / 10 * (LV_COLOR_DEPTH / 8))
uint32_t draw_buf[DRAW_BUF_SIZE / 4];

// Touchscreen coordinates
int x, y, z;

// Log function for debugging (LVGL logs)
void log_print(lv_log_level_t level, const char * buf) {
  LV_UNUSED(level);
  Serial.println(buf);
  Serial.flush();
}

// Function to read touchscreen data
void touchscreen_read(lv_indev_t * indev, lv_indev_data_t * data) {
  if (touchscreen.tirqTouched() && touchscreen.touched()) {
    TS_Point p = touchscreen.getPoint();
    // Map touchscreen coordinates to screen resolution
    x = map(p.x, 200, 3700, 0, SCREEN_WIDTH);
    y = map(p.y, 240, 3800, 0, SCREEN_HEIGHT);
    z = p.z;

    data->state = LV_INDEV_STATE_PRESSED; // Touch event
    data->point.x = x;
    data->point.y = y;
  } else {
    data->state = LV_INDEV_STATE_RELEASED; // Release event
  }
}

// Function to initialize everything (LVGL, touchscreen, SPI, etc.)
void setup_2432S028R() {
  String LVGL_Arduino = String("LVGL Library Version: ") + lv_version_major() + "." + lv_version_minor() + "." + lv_version_patch();
  Serial.println(LVGL_Arduino);

  // Initialize LVGL library
  lv_init();
  
  // Register print function for LVGL debug output
  lv_log_register_print_cb(log_print);

  // Initialize SPI for touchscreen
  touchscreenSPI.begin(XPT2046_CLK, XPT2046_MISO, XPT2046_MOSI, XPT2046_CS);
  touchscreen.begin(touchscreenSPI);
  
  // Set touchscreen rotation to landscape (adjust if necessary)
  touchscreen.setRotation(2);

  // Create display buffer for LVGL
  lv_display_t * disp;
  disp = lv_tft_espi_create(SCREEN_WIDTH, SCREEN_HEIGHT, draw_buf, sizeof(draw_buf));
  lv_display_set_rotation(disp, LV_DISPLAY_ROTATION_90); // Set display rotation to landscape

  // Initialize touchscreen input device for LVGL
  lv_indev_t * indev = lv_indev_create();
  lv_indev_set_type(indev, LV_INDEV_TYPE_POINTER);  // Set input type to pointer (touchscreen)
  lv_indev_set_read_cb(indev, touchscreen_read);    // Set callback to read touchscreen input
}

#endif // _2432S028R_H_
