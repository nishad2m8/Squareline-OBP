# WaveShare ESP32-S3-AMOLED-Touch-2.41

# Instruction

After exporting, rename the folder and files to match the following structure.


```

├── Template                              ├── Template
│   └── SLS-OBP-Your-Project              |   └── SLS-OBP-Your-Project
│       ├── libraries                 ➔   │       ├── lib
│       │   └──                           │       │   └── 
│       ├── platformio.ini                │       ├── platformio.ini
│       └── ui                        ➔   │       └── src
│           └── ui.ino                ➔   │           └── main.cpp
```