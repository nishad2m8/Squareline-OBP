# WaveShare ESP32-C6-1.47

[WaveShare ESP32-C6-1.47 Wiki](https://www.waveshare.com/wiki/ESP32-C6-LCD-1.47)

___

1. Open `Arduino` > `Settings`, then set the sketchbook location:
to the `Project` folder

### Project directory tree

```
Project/
├── libraries/
│   ├── lvgl/
│   └── ui/
├── ui/
│   └── ui.ino

```

2. Set board is `ESP32C6 Dev Module`, then select the correct `port`.

-  `Flash Size: "4MB (32Mb)`
-  `Partition Scheme: "No OTA (2MB APP/2MB FATFS)`

![alt text](ESP32-C6-LCD-1.47_Demo_3-1.png)