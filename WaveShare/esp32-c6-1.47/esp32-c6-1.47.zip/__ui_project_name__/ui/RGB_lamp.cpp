#include "RGB_lamp.h"

// This function writes the given color to your LED using your custom neopixelWrite function.
void Set_Color(uint8_t Red, uint8_t Green, uint8_t Blue) {
  neopixelWrite(PIN_NEOPIXEL, Red, Green, Blue);
}

void Update_RGB_Pattern(bool countUp, bool blinkState) {
  if (countUp) {
    // Count up: alternate between blue and purple.
    if (blinkState) {
      Set_Color(0, 0, 255);       // Blue
    } else {
      Set_Color(128, 0, 128);     // Purple
    }
  } else {
    // Count down: alternate between red and yellow.
    if (blinkState) {
      Set_Color(255, 0, 0);       // Red
    } else {
      Set_Color(255, 100, 0);     // Yellow
    }
  }
}
