#pragma once
#include "Arduino.h"

#define PIN_NEOPIXEL 8

// Function Prototypes (Declarations Only)
void Set_Color(uint8_t Red, uint8_t Green, uint8_t Blue);
void Update_RGB_Pattern(bool countUp, bool blinkState);
