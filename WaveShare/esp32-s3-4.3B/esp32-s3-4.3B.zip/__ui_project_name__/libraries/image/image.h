/*****************************************************************************
 * | File      	 :   image.h
 * | Author      :   Waveshare team
 * | Function    :   
 * | Info        :
 *                   
 *----------------
 * |This version :   V1.0
 * | Date        :   2024-11-19
 * | Info        :   Basic version
 *
 ******************************************************************************/
#ifndef __IMAGE_H
#define __IMAGE_H

extern const unsigned char gImage_picture[];
extern const unsigned char gImage_Bitmap[];
extern const unsigned char gImage_picture_90[];
extern const unsigned char gImage_Bitmap_90[];

#endif