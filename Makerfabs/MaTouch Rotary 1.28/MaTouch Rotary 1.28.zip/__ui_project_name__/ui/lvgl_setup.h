#ifndef LVGL_SETUP_H
#define LVGL_SETUP_H

void setupLVGL();

#endif
