# CrowPanel ESP32 E-Paper HMI 4.2-inch Display


```
// #if LV_COLOR_DEPTH != 16
//     #error "LV_COLOR_DEPTH should be 16bit to match SquareLine Studio's settings"
// #endif
```

```
   .header.cf = LV_COLOR_FORMAT_RGB565,
```