#ifndef LVGL_SETUP_H
#define LVGL_SETUP_H

#include <Arduino.h>
#include "lvgl.h"
#include "EPD_Init.h"

// Display object
extern lv_display_t *epd_display;

// Function declarations
void lvgl_init();

#endif // LVGL_SETUP_H