#include "lvgl_setup.h"
#include "EPD.h"

// LVGL display object
lv_display_t *epd_display = NULL;

// Display buffer - larger buffer for better performance
static uint8_t draw_buf[EPD_W * 100];  // Buffer for 100 lines

// Flush callback for LVGL
static void epd_flush_cb(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map) {
    uint32_t w = area->x2 - area->x1 + 1;
    uint32_t h = area->y2 - area->y1 + 1;
    
    // Convert LVGL buffer to EPD format
    // LVGL uses row-by-row format, EPD might need different format
    for(uint32_t y = 0; y < h; y++) {
        for(uint32_t x = 0; x < w; x++) {
            uint16_t x_pos = area->x1 + x;
            uint16_t y_pos = area->y1 + y;
            
            // Get pixel from LVGL buffer
            uint8_t pixel = px_map[y * w + x];
            
            // Convert grayscale to black/white
            // LVGL L8: 0 = black, 255 = white
            // EPD: BLACK = 0x00, WHITE = 0xFF
            uint8_t epd_color = (pixel > 127) ? WHITE : BLACK;
            
            // Set pixel using Paint functions
            Paint_SetPixel(x_pos, y_pos, epd_color);
        }
    }
    
    // Notify LVGL that flushing is done
    lv_display_flush_ready(disp);
}

// Initialize LVGL for EPD
void lvgl_init() {
    // Initialize LVGL
    lv_init();
    
    // Create display with EPD dimensions
    // Note: Using actual display dimensions 792x272, not 800x272
    epd_display = lv_display_create(792, 272);
    
    // Set the flush callback
    lv_display_set_flush_cb(epd_display, epd_flush_cb);
    
    // Set draw buffers
    lv_display_set_buffers(epd_display, draw_buf, NULL, sizeof(draw_buf), LV_DISPLAY_RENDER_MODE_PARTIAL);
    
    // Set color format to L8 (8-bit grayscale)
    lv_display_set_color_format(epd_display, LV_COLOR_FORMAT_L8);
    
    // Configure display for monochrome output
    lv_obj_t *scr = lv_display_get_screen_active(epd_display);
    lv_obj_set_style_bg_color(scr, lv_color_white(), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(scr, LV_OPA_COVER, LV_PART_MAIN);
}