
# Check here for setup instructions.  
## [Steps to run M5GFX on a PC.](https://github.com/m5stack/M5GFX/blob/master/examples/PlatformIO_SDL/README.md)
