#ifndef LVGL_SETUP_H
#define LVGL_SETUP_H

#include <Arduino.h>
#include "lvgl.h"
#include "EPD.h"

// External declarations
extern uint8_t Image_BW[15000];
extern lv_display_t *display;

// Function declarations
void lvgl_init();
void create_hello_world_ui();
void SetPixel(uint16_t x, uint16_t y, uint8_t color);
void ClearBuffer(uint8_t color);

#endif // LVGL_SETUP_H