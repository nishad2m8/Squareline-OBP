#include "lvgl_setup.h"

// LVGL display
lv_display_t *display = NULL;

// LVGL buffers - increased for better performance
static uint8_t lvgl_buf[EPD_W * 40]; // Buffer for 40 rows

// Function to set a pixel in the image buffer (replacing Paint_SetPixel)
void SetPixel(uint16_t x, uint16_t y, uint8_t color) {
    uint32_t addr;
    uint8_t rdata;
    
    // Calculate address in buffer
    addr = x / 8 + y * ((EPD_W % 8 == 0) ? (EPD_W / 8) : (EPD_W / 8 + 1));
    rdata = Image_BW[addr];
    
    if (color == 0) { // BLACK
        Image_BW[addr] = rdata & ~(0x80 >> (x % 8)); // Set bit to 0
    } else {
        Image_BW[addr] = rdata | (0x80 >> (x % 8));  // Set bit to 1
    }
}

// Function to clear the buffer
void ClearBuffer(uint8_t color) {
    uint16_t width_byte = (EPD_W % 8 == 0) ? (EPD_W / 8) : (EPD_W / 8 + 1);
    uint16_t height = EPD_H;
    
    for (uint16_t y = 0; y < height; y++) {
        for (uint16_t x = 0; x < width_byte; x++) {
            uint32_t addr = x + y * width_byte;
            Image_BW[addr] = color;
        }
    }
}

// Flush callback for LVGL
static void epd_flush_cb(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map) {
    // Calculate dimensions
    uint32_t width = area->x2 - area->x1 + 1;
    uint32_t height = area->y2 - area->y1 + 1;
    
    // Convert LVGL buffer to EPD format
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            uint8_t pixel = px_map[y * width + x];
            // Map: 0-127 -> BLACK, 128-255 -> WHITE
            SetPixel(area->x1 + x, area->y1 + y, pixel < 128 ? 0 : 1);
        }
    }
    
    // Tell LVGL we're done with this section
    lv_display_flush_ready(disp);
}

// Initialize LVGL
void lvgl_init() {
    // Initialize LVGL
    lv_init();
    
    // Create LVGL display
    display = lv_display_create(EPD_W, EPD_H);
    lv_display_set_flush_cb(display, epd_flush_cb);
    
    // Set up buffer with enough size to reduce number of flush operations
    lv_display_set_buffers(display, lvgl_buf, NULL, sizeof(lvgl_buf), LV_DISPLAY_RENDER_MODE_PARTIAL);
    
    // Set color format to 8-bit grayscale for E-Paper
    lv_display_set_color_format(display, LV_COLOR_FORMAT_L8);
    
    // Set white background
    lv_obj_set_style_bg_color(lv_screen_active(), lv_color_hex(0xFFFFFF), LV_PART_MAIN);
}
