
# M5Cardputer

## Basic library for M5Stack M5Cardputer Board 


License
----------------
M5GFX : [MIT](https://github.com/m5stack/M5GFX/blob/master/LICENSE)  
M5Unified : [MIT](https://github.com/m5stack/M5Unified/blob/master/LICENSE)  
 
