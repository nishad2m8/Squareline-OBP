#pragma once

#ifdef __cplusplus

#include "M5Unified.hpp"

#else

#error M5Unified requires a C++ compiler, please change file extension to .cc or .cpp

#endif
