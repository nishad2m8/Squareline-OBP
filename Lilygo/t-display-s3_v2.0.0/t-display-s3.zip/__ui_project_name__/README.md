# Lilygo T-Display S3 with LVGL 9.2.* and tft_espi

## Get started

1. rename ```libraries``` folder to  ```lib```
2. rename ```ui.ino``` file locatted in side ui folder  to ```main.cpp``` 
3. rename ```ui``` folder to ```scr```
4. open in in vs code using platformio compile and upload