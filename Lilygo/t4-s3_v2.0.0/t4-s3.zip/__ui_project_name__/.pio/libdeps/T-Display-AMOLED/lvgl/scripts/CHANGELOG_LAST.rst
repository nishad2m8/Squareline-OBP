`v9.2.1 <https://github.com/kisvegabor/lvgl_upstream/compare/v9.2.1...v9.2.1>`__ 29 October 2024
---------------------------------------------------------------------------------------------------------------------------------------------------

Breaking Changes
~~~~~~~~~~~~~~~~

Architectural
~~~~~~~~~~~~~

New Features
~~~~~~~~~~~~

Performance
~~~~~~~~~~~

Fixes
~~~~~

- **fix(nuttx): fix assert when release LCD draw buffer** `7159 <https://github.com/kisvegabor/lvgl_upstream/pull/7159>`__

- **fix(changelog): fix the version number** `2f70925 <https://github.com/kisvegabor/lvgl_upstream/commit/2f709251b4876332acdc541b0c96628c34c96104>`__

Examples
~~~~~~~~

Docs
~~~~

CI and tests
~~~~~~~~~~~~

Others
~~~~~~

- **Revert "fix(kconfig): add LV_ATTRIBUTE_MEM_ALIGN, LV_ATTRIBUTE_LARGE_CONST and LV_SYSMON_GET_IDLE configs (#7131)"** `932c140 <https://github.com/kisvegabor/lvgl_upstream/commit/932c14086b79aff2a27cd154441f680eb8257311>`__
