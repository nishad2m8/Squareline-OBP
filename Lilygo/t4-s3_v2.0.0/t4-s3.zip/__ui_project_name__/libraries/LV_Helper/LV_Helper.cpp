/**
 * @file      LV_Helper.cpp
 * @author    Lewis He (lewishe@outlook.com)
 * @license   MIT
 * @copyright Copyright (c) 2023  Shenzhen Xin Yuan Electronic Technology Co., Ltd
 * @date      2023-04-20
 * @note      Updated for LVGL 9.3 with RGB565 byte swapping support
 *
 */
#include <Arduino.h>
#include "LV_Helper.h"
// #include "lvgl/src/draw/sw/lv_draw_sw.h"  // For lv_draw_sw_rgb565_swap()

#if !LV_VERSION_CHECK(9,0,0)
#error "This version requires LVGL 9.x"
#endif

static lv_display_t * disp;
static lv_indev_t * indev;
static bool byte_swap_enabled = false;  // Runtime byte swap control

/* Display flushing with RGB565 byte swapping */
static void disp_flush(lv_display_t *disp, const lv_area_t *area, uint8_t *px_map)
{
    uint32_t w = lv_area_get_width(area);
    uint32_t h = lv_area_get_height(area);
    
    LilyGo_Display * board = (LilyGo_Display *)lv_display_get_user_data(disp);
    
    // Check if byte swapping is enabled (either by compile-time or runtime)
#if defined(LV_COLOR_16_SWAP) && LV_COLOR_16_SWAP
    // Use LVGL's built-in function to swap RGB565 bytes
    // This converts RRRRR GGG | GGG BBBBB to GGG BBBBB | RRRRR GGG
    uint32_t px_count = w * h;
    lv_draw_sw_rgb565_swap(px_map, px_count);
#else
    // Runtime byte swapping option
    if (byte_swap_enabled) {
        uint32_t px_count = w * h;
        lv_draw_sw_rgb565_swap(px_map, px_count);
    }
#endif
    
    board->pushColors(area->x1, area->y1, w, h, (uint16_t *)px_map);
    
    lv_display_flush_ready(disp);
}

/*Read the touchpad*/
static void touchpad_read(lv_indev_t *indev, lv_indev_data_t *data)
{
    static int16_t x, y;
    LilyGo_Display * board = (LilyGo_Display *)lv_indev_get_user_data(indev);
    uint8_t touched = board->getPoint(&x, &y, 1);
    
    if (touched) {
        data->point.x = x;
        data->point.y = y;
        data->state = LV_INDEV_STATE_PRESSED;
    } else {
        data->state = LV_INDEV_STATE_RELEASED;
    }
}

#ifndef BOARD_HAS_PSRAM
#error "Please turn on PSRAM to OPI !"
#else
static uint8_t *buf1 = NULL;
static uint8_t *buf2 = NULL;
#endif

#if LV_USE_LOG
void lv_log_print_g_cb(lv_log_level_t level, const char *buf)
{
    Serial.println(buf);
    Serial.flush();
}
#endif

static void lv_rounder_cb(lv_event_t * e)
{
    lv_area_t * area = (lv_area_t *)lv_event_get_param(e);
    
    // For partial refresh displays, ensure coordinates are even
    // This is important for some display controllers
    if (area->x1 & 1)
        area->x1--;
    if (!(area->x2 & 1))
        area->x2++;
    if (area->y1 & 1)
        area->y1--;
    if (!(area->y2 & 1))
        area->y2++;
}

void beginLvglHelper(LilyGo_Display &board, bool debug)
{
    lv_init();

#if LV_USE_LOG
    if (debug) {
        lv_log_register_print_cb(lv_log_print_g_cb);
    }
#endif

    uint32_t screen_width = board.width();
    uint32_t screen_height = board.height();
    
    // Calculate buffer size for LVGL 9.x
    // For smooth performance, use 1/10 of screen height but at least 16 lines
    uint32_t buf_lines = LV_MAX(screen_height / 10, 16);
    
    // For partial refresh displays, ensure buffer lines are even
    if (!board.needFullRefresh() && (buf_lines & 1)) {
        buf_lines++;
    }
    
    size_t buf_size = screen_width * buf_lines * sizeof(lv_color_t);
    
    // Allocate draw buffers in PSRAM
    buf1 = (uint8_t *)ps_malloc(buf_size);
    assert(buf1);
    
    // For double buffering (recommended for smooth performance)
    buf2 = (uint8_t *)ps_malloc(buf_size);
    assert(buf2);

    // Initialize the display
    disp = lv_display_create(screen_width, screen_height);
    lv_display_set_user_data(disp, &board);
    lv_display_set_flush_cb(disp, disp_flush);
    
    // Configure display buffers and render mode
    bool full_refresh = board.needFullRefresh();
    if (full_refresh) {
        // For full refresh displays (like 1.47" AMOLED)
        lv_display_set_buffers(disp, buf1, buf2, buf_size, LV_DISPLAY_RENDER_MODE_FULL);
    } else {
        // For partial refresh displays (like 1.91" and 2.41" AMOLED)
        lv_display_set_buffers(disp, buf1, buf2, buf_size, LV_DISPLAY_RENDER_MODE_PARTIAL);
        // Add rounder callback for partial refresh
        lv_display_add_event_cb(disp, lv_rounder_cb, LV_EVENT_INVALIDATE_AREA, NULL);
    }
    
    // Set color format based on configuration
#if LV_COLOR_DEPTH == 16
    lv_display_set_color_format(disp, LV_COLOR_FORMAT_RGB565);
#elif LV_COLOR_DEPTH == 32
    lv_display_set_color_format(disp, LV_COLOR_FORMAT_XRGB8888);
#endif

    // Initialize input device if touch is available
    if (board.hasTouch()) {
        indev = lv_indev_create();
        lv_indev_set_type(indev, LV_INDEV_TYPE_POINTER);
        lv_indev_set_user_data(indev, &board);
        lv_indev_set_read_cb(indev, touchpad_read);
    }
    
    // Set default theme
#if LV_USE_THEME_DEFAULT
    lv_theme_default_init(disp, 
                          lv_palette_main(LV_PALETTE_BLUE), 
                          lv_palette_main(LV_PALETTE_RED),
                          LV_THEME_DEFAULT_DARK, 
                          LV_FONT_DEFAULT);
#endif
}

void setRGB565ByteSwap(bool enable)
{
    byte_swap_enabled = enable;
}

lv_display_t* getLvglDisplay()
{
    return disp;
}

lv_indev_t* getLvglInputDevice()
{
    return indev;
}