/**
 * @file      LV_Helper.h
 * @author    Lewis He (lewishe@outlook.com)
 * @license   MIT
 * @copyright Copyright (c) 2023  Shenzhen Xin Yuan Electronic Technology Co., Ltd
 * @date      2023-04-20
 * @note      Updated for LVGL 9.3 with RGB565 byte swapping support
 *
 */

#pragma once
#include <lvgl.h>
#include "LilyGo_Display.h"

/**
 * @brief Initialize LVGL with the LilyGo display
 * 
 * @param board Reference to the LilyGo_Display object
 * @param debug Enable debug logging (default: false)
 */
void beginLvglHelper(LilyGo_Display &board, bool debug = false);

/**
 * @brief Enable or disable RGB565 byte swapping at runtime
 * 
 * @param enable true to enable byte swapping, false to disable
 */
void setRGB565ByteSwap(bool enable);

/**
 * @brief Get the LVGL display object
 * 
 * @return lv_display_t* Pointer to the LVGL display
 */
lv_display_t* getLvglDisplay();

/**
 * @brief Get the LVGL input device object
 * 
 * @return lv_indev_t* Pointer to the LVGL input device (touchscreen)
 */
lv_indev_t* getLvglInputDevice();