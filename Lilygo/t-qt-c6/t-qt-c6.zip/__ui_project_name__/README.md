# Lilygo T-QT C6

1. Open `Arduino` > `Settings`, then set the sketchbook location:
to the `Project` folder

### Project directory tree

```
Project/
├── libraries/
│   ├── Arduino_DriveBus-1.1.10/
│   ├── Arduino_GFX-1.3.7/
│   ├── KalmanFilter/
│   ├── lvgl-8.3.5/
│   ├── Mylibrary/
│   └── ui/
├── ui/
│   └── ui.ino

```

2. Set board is `ESP32C6 Dev Module`, then select the correct `port`.